<?php
session_start();
include 'db.php';

if ($_SESSION['status_login'] != true) {
    echo '<script>window.location="login.php"</script>';
}

// Mendapatkan ID gambar dari URL
$image_id = $_GET['id'];

// Mengambil jumlah likes saat ini
$query = mysqli_query($conn, "SELECT likes FROM tb_image WHERE image_id = '$image_id'");
$data = mysqli_fetch_assoc($query);

// Memastikan bahwa data ditemukan
if ($data) {
    $current_likes = $data['likes']; // Ambil jumlah likes saat ini
    $new_likes = $current_likes + 1; // Tambah satu like

    // Memperbarui jumlah likes di database
    $update_likes = mysqli_query($conn, "UPDATE tb_image SET likes = '$new_likes' WHERE image_id = '$image_id'");

    if ($update_likes) {
        echo '<script>alert("Like berhasil ditambahkan!"); window.location="galeri.php";</script>';
    } else {
        echo '<script>alert("Gagal menambahkan like."); window.location="galeri.php";</script>';
    }
} else {
    echo '<script>alert("Gambar tidak ditemukan."); window.location="galeri.php";</script>';
}
?>
