<?php
session_start();
include 'db.php';

if ($_SESSION['status_login'] != true) {
    echo '<script>window.location="login.php"</script>';
}

// Memastikan ID gambar ada di URL
if (!isset($_GET['id'])) {
    echo '<script>alert("ID foto Tidak Ditemukan."); window.location="galeri.php";</script>';
    exit();
}

$image_id = $_GET['id'];

// Proses pengiriman komentar
if (isset($_POST['submit_comment'])) {
    $user_id = $_SESSION['a_global']->admin_id; // Ambil ID pengguna dari sesi
    $comment_text = $_POST['comment_text'];

    // Menyimpan komentar ke dalam database
    $insert_comment = mysqli_query($conn, "INSERT INTO tb_comments (image_id, user_id, comment_text) VALUES ('$image_id', '$user_id', '$comment_text')");

    if ($insert_comment) {
        echo '<script>alert("Komentar berhasil ditambahkan!"); window.location="komentar.php?id=' . $image_id . '";</script>';
    } else {
        echo '<script>alert("Gagal menambahkan komentar."); window.location="komentar.php?id=' . $image_id . '";</script>';
    }
}

// Mengambil komentar dari database
$comments_query = mysqli_query($conn, "SELECT c.comment_text, c.date_created, a.admin_name FROM tb_comments c JOIN tb_admin a ON c.user_id = a.admin_id WHERE c.image_id = '$image_id' ORDER BY c.date_created DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Komentar Foto</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1><a href="index.php">WEB GALERI FOTO</a></h1>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="profil.php">Profil</a></li>
                <li><a href="data-image.php">Data Foto</a></li>
                <li><a href="keluar.php">Keluar</a></li>
            </ul>
        </div>
    </header>

    <div class="section">
        <div class="container">
            <h3>Komentar untuk Foto ID: <?php echo htmlspecialchars($image_id); ?></h3>
            <div class="box">
                <!-- Form untuk menambahkan komentar -->
                <form action="" method="POST">
                    <textarea name="comment_text" required placeholder="Tulis komentar..."></textarea>
                    <input type="submit" name="submit_comment" value="Kirim Komentar">
                </form>

                <h4>Daftar Komentar:</h4>
                <ul>
                    <?php while ($comment = mysqli_fetch_assoc($comments_query)) { ?>
                        <li>
                            <strong><?php echo htmlspecialchars($comment['admin_name']); ?></strong>: <?php echo htmlspecialchars($comment['comment_text']); ?> <br>
                            <small><?php echo htmlspecialchars($comment['date_created']); ?></small>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <small>Copyright &copy; 2024 - Web Galeri Foto.</small>
        </div>
    </footer>
</body>
</html>
